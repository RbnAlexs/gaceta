
______      _     _ _     _               
| ___ \    | |   | (_)   | |              
| |_/ /   _| |__ | |_ ___| |__   ___ _ __ 
|  __/ | | | '_ \| | / __| '_ \ / _ \ '__|
| |  | |_| | |_) | | \__ \ | | |  __/ |   
\_|   \__,_|_.__/|_|_|___/_| |_|\___|_|   


\—-> BetterStudio, 2017 <—-/
  
The online documentations is here: 
http://community.betterstudio.com/publisher-doc/